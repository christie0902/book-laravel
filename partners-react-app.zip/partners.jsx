import React from 'react';
import ReactDOM from 'react-dom/client';
import Partners from './partners/Partners';

const root = ReactDOM.createRoot(document.getElementById('partners'));
root.render(
    <Partners />
);